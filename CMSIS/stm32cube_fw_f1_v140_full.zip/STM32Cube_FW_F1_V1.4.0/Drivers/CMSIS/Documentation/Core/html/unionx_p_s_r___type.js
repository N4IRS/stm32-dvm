var unionx_p_s_r___type =
[
    [ "_reserved0", "unionx_p_s_r___type.html#af438e0f407357e914a70b5bd4d6a97c5", null ],
    [ "b", "unionx_p_s_r___type.html#a3b1063bb5cdad67e037cba993b693b70", null ],
    [ "C", "unionx_p_s_r___type.html#a40213a6b5620410cac83b0d89564609d", null ],
    [ "ISR", "unionx_p_s_r___type.html#a3e9120dcf1a829fc8d2302b4d0673970", null ],
    [ "IT", "unionx_p_s_r___type.html#a3200966922a194d84425e2807a7f1328", null ],
    [ "N", "unionx_p_s_r___type.html#a2db9a52f6d42809627d1a7a607c5dbc5", null ],
    [ "Q", "unionx_p_s_r___type.html#add7cbd2b0abd8954d62cd7831796ac7c", null ],
    [ "T", "unionx_p_s_r___type.html#a7eed9fe24ae8d354cd76ae1c1110a658", null ],
    [ "V", "unionx_p_s_r___type.html#af14df16ea0690070c45b95f2116b7a0a", null ],
    [ "w", "unionx_p_s_r___type.html#a1a47176768f45f79076c4f5b1b534bc2", null ],
    [ "Z", "unionx_p_s_r___type.html#a1e5d9801013d5146f2e02d9b7b3da562", null ]
];